<?php
session_start();
include 'conexion.php'; // conecta a la base de datos

$usuario_guardado = isset($_COOKIE["login"]) ? $_COOKIE["login"] : "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $_POST["login"];
    $pass = $_POST["pass"];

    // Buscar usuario por nombre o correo (ajusta si prefieres uno solo)
    $sql = "SELECT usuario, correo, contrasena FROM usuarios WHERE usuario = ? OR correo = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $login, $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $fila = $result->fetch_assoc();
        $hash = $fila['contrasena'];


        if (password_verify($pass, $hash)) {
    // Vaciar carrito al iniciar sesión
    $_SESSION['carrito'] = array();

    // Contraseña correcta: asignar tipo usuario según dominio correo
    $correo = $fila['correo'];
    if (str_ends_with($correo, '@admin.tranquilatte.com')) {
        $_SESSION["tipo_usuario"] = "administrador";
        $_SESSION["usuario"] = $fila['usuario'];
        $redirect = "admin.php";
    } else {
        $_SESSION["tipo_usuario"] = "generico";
        $_SESSION["usuario"] = $fila['usuario'];
        $redirect = "principal.php";
    }

    if (isset($_POST["recordar"])) {
        setcookie("login", $login, time() + 604800, "/"); // 7 días
    } else {
        setcookie("login", "", time() - 3600, "/");
    }

    header("Location: $redirect");
    exit();
}
 else {
            // Contraseña incorrecta
            header("Location: error.php");
            exit();
        }
    } else {
        // Usuario no encontrado
        header("Location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Tranquillate - Iniciar Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* ... aquí va tu  sin cambios ... */
        body {
            background-image: url('img/fondo-cafe.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            backdrop-filter: blur(5px);
            height: 100vh;
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
        }
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 20px;
            padding: 30px 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            animation: fadeIn 1s ease-in-out;
        }
        .logo {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo img {
            width: 70px;
        }
        .btn-cafe {
            background-color: #6f4e37;
            color: white;
            border: none;
            transition: background-color 0.3s ease;
        }
        .btn-cafe:hover {
            background-color: #54382b;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .text-center a {
            color: #6f4e37;
            text-decoration: none;
        }
        .text-center a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="logo">
                <img src="img/taza.png" alt="Tranquillate">
                <h3 class="mt-2">Tranquillate Café</h3>
            </div>
            <form method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                <div class="mb-3">
                    <label for="login" class="form-label">Usuario o correo</label>
                    <input type="text" class="form-control" id="login" name="login" required value="<?= htmlspecialchars($usuario_guardado) ?>">
                </div>
               <div class="mb-3">
                <label for="pass" class="form-label">Contraseña</label>
                <div class="input-group">
                <input type="password" class="form-control" id="pass" name="pass" required>
                <button class="btn btn-outline-secondary" type="button" id="togglePassword">👁️
                 </button>
                </div>
            </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="recordar" name="recordar" <?= $usuario_guardado ? 'checked' : '' ?>>
                    <label class="form-check-label" for="recordar">Recordar usuario</label>
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-cafe">Ingresar</button>
                </div>
                <div class="text-center mt-3">
                    <small>¿No tienes una cuenta? <a href="registro.php">Regístrate</a></small>
                </div>
            </form>
        </div>
    </div>
    <script>
    const togglePassword = document.getElementById('togglePassword');
    const passwordField = document.getElementById('pass');

    togglePassword.addEventListener('click', () => {
        const type = passwordField.type === 'password' ? 'text' : 'password';
        passwordField.type = type;
        togglePassword.textContent = type === 'password' ? '👁️' : '🙈';
    });
</script>

</body>
</html>

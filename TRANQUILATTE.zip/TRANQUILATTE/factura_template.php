<?php
session_start();

$carrito = $_SESSION['carrito'] ?? [];
$cliente = $_SESSION['datos_pedido'] ?? [];

// Si no hay ticket_productos, lo tomamos del carrito directamente
if (!isset($_SESSION['ticket_productos'])) {
    $_SESSION['ticket_productos'] = $carrito;
}

$productos = $_SESSION['ticket_productos'] ?? [];

// Por si vienen como JSON (solo en caso extremo)
if (is_string($productos)) {
    $productos = json_decode($productos, true);
}


$total = 0;
foreach ($productos as $nombre => $producto) {
    if (isset($producto['precio'], $producto['cantidad'])) {
        $subtotal = floatval($producto['precio']) * intval($producto['cantidad']);
        $total += $subtotal;
    }
}

$fecha = date('Y-m-d H:i:s');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Ticket de Compra</title>
</head>
<body>
    <h1 style="text-align:center;">Ticket de Compra</h1>
    <p><strong>Cliente:</strong> <?= htmlspecialchars($cliente['nombre_cliente'] ?? '---') ?></p>
    <p><strong>Dirección:</strong> <?= htmlspecialchars($cliente['direccion'] ?? '---') ?></p>
    <p><strong>Teléfono:</strong> <?= htmlspecialchars($cliente['telefono'] ?? '---') ?></p>
    <p><strong>Método de pago:</strong> <?= htmlspecialchars($cliente['metodo_pago'] ?? '---') ?></p>
    <p><strong>Fecha:</strong> <?= $fecha ?></p>

    <h3>Detalle del pedido:</h3>
    <table border="1" cellspacing="0" cellpadding="5" width="100%">
        <tr>
            <th>Producto</th>
            <th>Precio</th>
            <th>Cantidad</th>
            <th>Subtotal</th>
        </tr>
        <?php foreach ($productos as $nombre => $producto): ?>
            <tr>
                <td><?= htmlspecialchars($nombre) ?></td>
                <td>$<?= number_format($producto['precio'], 2) ?></td>
                <td><?= intval($producto['cantidad']) ?></td>
                <td>$<?= number_format($producto['precio'] * $producto['cantidad'], 2) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <p style="text-align:right; font-size: 18px;"><strong>Total: $<?= number_format($total, 2) ?></strong></p>
</body>
</html>

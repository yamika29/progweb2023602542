-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-06-2025 a las 00:42:08
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cafes`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ordenes`
--

CREATE TABLE `ordenes` (
  `id` int(11) NOT NULL,
  `nombre_cliente` varchar(255) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `metodo_pago` varchar(50) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ordenes`
--

INSERT INTO `ordenes` (`id`, `nombre_cliente`, `direccion`, `telefono`, `metodo_pago`, `total`, `fecha`) VALUES
(1, 'prueba 1', 'preubas 1', '389389283939283', 'Efectivo', 58.00, '2025-06-23 02:20:07'),
(2, 'wewre', 'C LAUREL 27 27, 1', '098098080808098', 'Efectivo', 198.00, '2025-06-23 02:23:08'),
(3, NULL, NULL, NULL, NULL, 20.00, '2025-06-23 02:26:23'),
(4, 'karla ', 'C LAUREL 27 27, 1', '345678900009099', 'Efectivo', 20.00, '2025-06-23 02:34:00'),
(5, 'PRUEBA', 'EN TU CORAZON 1', '235478921567212', 'Efectivo', 147.00, '2025-06-23 02:36:05'),
(6, 'Brenda Hernandez', 'C LAUREL 27 27, 1', '8989898989', 'Efectivo', 20.00, '2025-06-23 02:38:37'),
(7, 'PRUEBA PDF', 'EN TU CORAZON ', '7834364764', 'Efectivo', 108.00, '2025-06-23 15:57:23'),
(8, 'PRUEBA 2.0', 'EN TU CORAZON ', '3674637899', 'Efectivo', 54.00, '2025-06-23 16:32:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden_detalles`
--

CREATE TABLE `orden_detalles` (
  `id` int(11) NOT NULL,
  `orden_id` int(11) DEFAULT NULL,
  `producto` varchar(255) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `orden_detalles`
--

INSERT INTO `orden_detalles` (`id`, `orden_id`, `producto`, `precio`, `cantidad`) VALUES
(1, 1, 'Yogur con granola y frutas', 28.00, 1),
(2, 1, 'Ensaladas', 30.00, 1),
(3, 2, 'Wraps', 33.00, 6),
(4, 3, 'Muffin de chocolate ', 20.00, 1),
(5, 4, 'Muffin de chocolate ', 20.00, 1),
(6, 5, 'Café descafeinado', 27.00, 3),
(7, 5, 'Croissants', 22.00, 3),
(8, 6, 'Muffin de chocolate ', 20.00, 1),
(9, 7, 'Café descafeinado', 27.00, 4),
(10, 8, 'Café descafeinado', 27.00, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `nombre_cliente` varchar(255) DEFAULT NULL,
  `producto` varchar(255) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `nombre_cliente`, `producto`, `cantidad`, `fecha`) VALUES
(1, 'karla', 'Matcha latte - $34.00', 2, '2025-06-23 15:48:01'),
(2, 'Prueba CRUD editar', 'Matcha latte - $34.00', 2, '2025-06-23 15:48:31');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `correo`, `contrasena`, `fecha_registro`) VALUES
(1, 'chiwis', 'chiwis@gmail', '$2y$10$JplkowMIKQOSB2maq31XAuV/c7C79kZTeJRpGLUKvjlyspU2u25f.', '2025-06-05 16:17:56'),
(2, 'uri', 'uri@gmail.com', '$2y$10$oG9c1OEYUORG1uK/a4fMNuLbj.LB6vQSbVFCHpUfiEad06im.FKd2', '2025-06-05 16:21:57'),
(3, 'joel', 'joel@gmail', '$2y$10$Ec7oxTPDU4C9QMNx4VKjmugYHBa4xdrNPt2pF8i/1RpzcRiKccaw2', '2025-06-05 16:28:10'),
(4, 'michele', 'michele@gmail.com', '$2y$10$1aL8pNHOa2q1nrxhP3bR2u2hLFLd73tdV2kggI8xVmYDvvlvNX2ye', '2025-06-05 16:31:16'),
(5, 'michelada', 'michelada@admin.tranquilatte.com', '$2y$10$fqqgOV3sAo1ok.cz/uTYheKTrK7VDTdfURaauyHEbF4BFQmTJKfNW', '2025-06-05 16:32:17'),
(6, 'picaza', 'picaza@gmail.com', '$2y$10$MPn89TgBTz/Wo2068tdfz.YVjk0C3MDu505iwIhAcmNPepK0F//RS', '2025-06-05 16:39:50'),
(13, 'michelada', 'mich@admin.tranquilatte.com', '$2y$10$XXyR4JKr9syz2lEU2GtTwulH/JpbAGMjCAeglr4i3Ajrf2S2M7u.G', '2025-06-17 15:30:33'),
(15, 'hernandez', 'soiwoi@gmail.com', '$2y$10$FEYhcHemtEUDeYqPV3BtI.AVRb7M.5cIsFBPuPfW3oVkVRnEPaKaq', '2025-06-23 07:28:15'),
(17, 'Karla Yamilth ', 'yamihp9@gmail.com', '$2y$10$hLITh81na7sDmb3yYt31wOv2.GKL0XgrghzeEkcvj9.ddaW1GjiSK', '2025-06-23 21:55:27');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `orden_detalles`
--
ALTER TABLE `orden_detalles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orden_id` (`orden_id`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ordenes`
--
ALTER TABLE `ordenes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `orden_detalles`
--
ALTER TABLE `orden_detalles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `orden_detalles`
--
ALTER TABLE `orden_detalles`
  ADD CONSTRAINT `orden_detalles_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

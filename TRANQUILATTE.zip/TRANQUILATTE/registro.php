<?php
include 'conexion.php';

$mensaje = "";
$tipoMensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST["usuario"];
    $correo = $_POST["correo"];
    $contrasena = $_POST["contrasena"];

    // Validación para admins
    $esAdmin = str_ends_with($correo, '@admin.tranquilatte.com');
    $esDominioInvalidoAdmin = str_contains($correo, 'admin') && !$esAdmin;

    if ($esDominioInvalidoAdmin) {
        $mensaje = "Los correos de administrador deben terminar en @admin.tranquilatte.com";
        $tipoMensaje = "error";
    } else {
        // Verificar si el correo ya existe
        $sql_check = "SELECT id FROM usuarios WHERE correo = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("s", $correo);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            $mensaje = "Este correo ya está registrado. Usa otro o inicia sesión.";
            $tipoMensaje = "error";
        } else {
            // Cifrar contraseña
            $hash = password_hash($contrasena, PASSWORD_DEFAULT);

            // Insertar en la base de datos
            $sql = "INSERT INTO usuarios (usuario, correo, contrasena) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $usuario, $correo, $hash);

            if ($stmt->execute()) {
                echo "
                <script>
                    alert('Registro exitoso. Serás redirigido al login.');
                    window.location.href = 'login.php';
                </script>";
                $stmt->close();
                $conn->close();
                exit();
            } else {
                $mensaje = "Error al registrar: " . $stmt->error;
                $tipoMensaje = "error";
            }

            $stmt->close();
        }

        $stmt_check->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body class="bg-light d-flex justify-content-center align-items-center" style="height: 100vh; background-image: url('img/fondo-cafe.jpg'); background-size: cover; background-position: center;">
    <div class="card shadow p-4" style="width: 100%; max-width: 450px;">
        <img src="img/taza.png" alt="Tranquillate" style="display: block; margin: 0 auto; width: 100px;">
        <h4 class="text-center mb-4">Crear Cuenta</h4>

        <form method="post" action="">
            <div class="mb-3">
                <label for="usuario" class="form-label">Nombre de usuario</label>
                <input type="text" class="form-control" id="usuario" name="usuario" required>
            </div>
            <div class="mb-3">
                <label for="correo" class="form-label">Correo electrónico</label>
                <input type="email" class="form-control" id="correo" name="correo" required>
            </div>
            <div class="mb-3">
                <label for="contrasena" class="form-label">Contraseña</label>
                <input type="password" class="form-control" id="contrasena" name="contrasena" required>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-success">Registrarse</button>
            </div>
        </form>
    </div>

    <?php if ($mensaje): ?>
    <script>
        alert('<?php echo $mensaje; ?>');
    </script>
    <?php endif; ?>
</body>
</html>

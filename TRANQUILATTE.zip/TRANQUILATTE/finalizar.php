<?php 
session_start();
include 'conexion.php';

if (!isset($_SESSION['carrito']) || !isset($_POST['confirmar_pedido'])) {
    header("Location: productos.php");
    exit();
}

$direccion = trim($_POST['direccion'] ?? '');
$metodo_pago = trim($_POST['metodo_pago'] ?? '');
$telefono = trim($_POST['telefono'] ?? '');
$nombre_cliente = trim($_POST['nombre_cliente'] ?? '');

if ($direccion === '' || $metodo_pago === '' || $telefono === '' || $nombre_cliente === '') {
    die("Faltan datos en el formulario.");
}

$productos = $_SESSION['carrito'];
$total = 0;
foreach ($productos as $producto) {
    $total += $producto['precio'] * $producto['cantidad'];
}

// CONEXIÓN MYSQLI (usa tu usuario, contraseña y base correctos)
$conexion = new mysqli('localhost', 'root', '', 'cafes');
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Insertar orden
$fecha = date('Y-m-d H:i:s');
$stmt = $conexion->prepare("INSERT INTO ordenes (nombre_cliente, direccion, telefono, metodo_pago, total, fecha) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssds", $nombre_cliente, $direccion, $telefono, $metodo_pago, $total, $fecha);
$stmt->execute();
$id_orden = $stmt->insert_id;
$stmt->close();

// Insertar detalles

$stmt = $conexion->prepare("INSERT INTO orden_detalles (orden_id, producto, precio, cantidad) VALUES (?, ?, ?, ?)");
foreach ($productos as $nombre => $producto) {
    $precio = floatval($producto['precio']);
    $cantidad = intval($producto['cantidad']);
    $subtotal = $precio * $cantidad;
    $stmt->bind_param("isdi", $id_orden, $nombre, $precio, $cantidad);
    $stmt->execute();
}
$stmt->close();
$conexion->close();

// Guardar datos para el ticket
$_SESSION['datos_pedido'] = [
    'nombre_cliente' => $nombre_cliente,
    'direccion' => $direccion,
    'telefono' => $telefono,
    'metodo_pago' => $metodo_pago,
];
$_SESSION['ticket_productos'] = $productos;
$_SESSION['carrito'] = []; // limpiar carrito
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gracias por tu compra</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9f3ef;
            color: #4e342e;
            margin: 0;
            padding: 0;
        }
        .contenedor {
            max-width: 700px;
            margin: 60px auto;
            background-color: #fff8f1;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(80, 40, 20, 0.1);
        }
        h1 {
            color: #6b4226;
            text-align: center;
            margin-bottom: 25px;
        }
        p {
            font-size: 1.1rem;
            margin: 8px 0;
        }
        h2 {
            margin-top: 35px;
            color: #8b5e3c;
            border-bottom: 2px solid #d9b382;
            padding-bottom: 6px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            border: 1px solid #d9b382;
            padding: 10px 12px;
            text-align: center;
        }
        th {
            background-color: #f1d7a3;
            color: #6b4226;
        }
        tbody tr:nth-child(even) {
            background-color: #f7ecd4;
        }
        .total {
            margin-top: 20px;
            font-weight: bold;
            font-size: 1.3rem;
            color: #a0522d;
            text-align: right;
        }
        .btn-regresar {
            display: block;
            width: 100%;
            margin-top: 40px;
            text-align: center;
            padding: 12px;
            background-color: #8b4513;
            color: white;
            border: none;
            border-radius: 10px;
            text-decoration: none;
            font-size: 1.1rem;
            transition: background-color 0.3s ease;
        }
        .btn-regresar:hover {
            background-color: #6b3310;
        }
    </style>
</head>
<body>
    <div class="contenedor">
        <h1>¡Gracias por tu compra, <?= htmlspecialchars($nombre_cliente) ?>!</h1>

        <p><strong>Dirección:</strong> <?= htmlspecialchars($direccion) ?></p>
        <p><strong>Teléfono:</strong> <?= htmlspecialchars($telefono) ?></p>
        <p><strong>Método de pago:</strong> <?= htmlspecialchars($metodo_pago) ?></p>

        <h2>Resumen del pedido:</h2>
        <table>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Precio unitario</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($productos as $nombre => $producto): ?>
                    <tr>
                        <td><?= htmlspecialchars($nombre) ?></td>
                        <td>$<?= number_format(floatval($producto['precio']), 2) ?></td>
                        <td><?= intval($producto['cantidad']) ?></td>
                        <td>$<?= number_format(floatval($producto['precio']) * intval($producto['cantidad']), 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <p class="total">Total a pagar: $<?= number_format($total, 2) ?></p>

        <a class="btn-regresar" href="productos.php">Volver al menú principal</a>
         <a class="btn-regresar" href="generar_ticket.php">Descargar PDF</a>
    </div>
</body>
</html>

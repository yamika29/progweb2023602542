<?php
$archivo = 'pedidos.json';
$pedidos = [];

if (file_exists($archivo)) {
    $contenido = file_get_contents($archivo);
    $pedidos = json_decode($contenido, true) ?? [];
}

// Eliminar pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar'])) {
    $index = $_POST['eliminar'];
    if (isset($pedidos[$index])) {
        array_splice($pedidos, $index, 1);
        file_put_contents($archivo, json_encode($pedidos, JSON_PRETTY_PRINT));
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

// Actualizar entregado/pagado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar'])) {
    $index = $_POST['actualizar'];
    if (isset($pedidos[$index])) {
        $pedidos[$index]['entregado'] = isset($_POST['entregado']) ? true : false;
        $pedidos[$index]['pagado'] = isset($_POST['pagado']) ? true : false;
        file_put_contents($archivo, json_encode($pedidos, JSON_PRETTY_PRINT));
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pedidos Realizados</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f4f1;
            padding: 40px;
            background-image: url('img/fondo-cafe.jpg');
        }
        h1 {
            text-align: center;
            color: #5a2e0e;
        }
        .tabla-contenedor {
            max-width: 1000px;
            margin: auto;
            background-color: #fff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #a0522d;
            color: white;
        }
        tr:hover {
            background-color: #f1e8e4;
        }
        .pedido {
            margin-top: 40px;
            border: 2px dashed #a0522d;
            padding: 15px;
            border-radius: 10px;
        }
        .vacio {
            text-align: center;
            font-size: 1.1em;
            color: #a00;
            margin-top: 30px;
        }
        .btn-regresar {
            display: block;
            width: 160px;
            margin: 30px auto 0 auto;
            padding: 12px 0;
            text-align: center;
            background-color: #a0522d;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            box-shadow: 0 4px 8px rgba(160, 82, 45, 0.3);
            transition: background-color 0.3s ease;
        }
        .btn-regresar:hover {
            background-color: #7a3810;
        }
        .acciones {
            margin-top: 15px;
        }
        .acciones label {
            margin-right: 20px;
        }
        .acciones input[type="submit"] {
            background-color: #a0522d;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            margin-right: 10px;
        }
        .acciones input[type="submit"]:hover {
            background-color: #7a3810;
        }
        .acciones form {
            display: inline;
        }
    </style>
</head>
<body>

<h1>Pedidos Realizados</h1>

<div class="tabla-contenedor">
<?php if (count($pedidos) === 0): ?>
    <p class="vacio">No hay pedidos registrados todavía.</p>
<?php else: ?>
    <?php foreach ($pedidos as $index => $pedido): ?>
        <?php
            // Aseguramos que existan los campos
            if (!isset($pedido['entregado'])) $pedido['entregado'] = false;
            if (!isset($pedido['pagado'])) $pedido['pagado'] = false;
        ?>
        <div class="pedido">
            <h3>Pedido #<?= $index + 1 ?> - <?= htmlspecialchars($pedido['cliente']['nombre_cliente']) ?> (<?= $pedido['fecha'] ?>)</h3>
            <p><strong>Dirección:</strong> <?= htmlspecialchars($pedido['cliente']['direccion']) ?></p>
            <p><strong>Teléfono:</strong> <?= htmlspecialchars($pedido['cliente']['telefono']) ?></p>
            <p><strong>Método de pago:</strong> <?= htmlspecialchars($pedido['cliente']['metodo_pago']) ?></p>

            <table>
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pedido['productos'] as $nombre => $producto): ?>
                        <tr>
                            <td><?= htmlspecialchars($nombre) ?></td>
                            <td>$<?= number_format($producto['precio'], 2) ?></td>
                            <td><?= $producto['cantidad'] ?></td>
                            <td>$<?= number_format($producto['precio'] * $producto['cantidad'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <p><strong>Total:</strong> $<?= number_format($pedido['total'], 2) ?></p>

            <div class="acciones">
                <!-- Formulario para actualizar entregado/pagado -->
                <form method="post">
                    <input type="hidden" name="actualizar" value="<?= $index ?>">
                    <label><input type="checkbox" name="entregado" <?= $pedido['entregado'] ? 'checked' : '' ?>> Entregado</label>
                    <label><input type="checkbox" name="pagado" <?= $pedido['pagado'] ? 'checked' : '' ?>> Pagado</label>
                    <input type="submit" value="Guardar cambios">
                </form>

                <!-- Formulario para eliminar -->
                <form method="post">
                    <input type="hidden" name="eliminar" value="<?= $index ?>">
                    <input type="submit" value="Eliminar">
                </form>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
</div>

<a href="admin.php" class="btn-regresar">← Regresar al Panel</a>

</body>
</html>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Panel del Gerente - Tranquilatte Cafeteria's</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-image: url('img/fondo-cafe.jpg');

    }

    .sidebar {
      background-color:rgb(139, 105, 91);
      min-height: 300vh;
      width: 350px;
      text-align: center;
      padding-top: 2rem;
      color: #fff;
    }
    .logo-container {
      margin: 0 auto 1.5rem auto;
      width: 130px;
      height: 130px;
    }
    .logo-container img {
      width: 100%;
      height: auto;
      object-fit: contain;
      border-radius: 50%;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }
    .content {
      background-color:rgba(239, 238, 229, 1);
      border-left: 1px solid #ddd;
      padding: 2rem 3rem;
      flex-grow: 1;
    }
    .sidebar a.nav-link {
      color: #ffffff;
      text-align: left;
      padding-left: 1rem;
      cursor: pointer;
    }

    .sidebar a.nav-link:hover,
    .sidebar a.nav-link.active {
      background-color: #8B5E3C; /* Color más claro al pasar */
      padding-left: 1.5rem;
      border-radius: 5px;
      color: #fff;
      text-decoration: none;
    }

    .form-label {
      color: #4e342e; /* Chocolate */
      font-weight: 600;
    }

    .btn-primary {
      background-color: #8B5E3C;
      border-color: #8B5E3C;
    }

    .btn-primary:hover {
      background-color: #A9746E;
      border-color: #A9746E;
    }

    .suggestion-card {
      background-color: #f4ebe0;
      border-radius: 10px;
      padding: 1rem;
      margin-bottom: 1rem;
      box-shadow: 2px 2px 6px rgba(124, 79, 61, 0.3);
      color: #3e2c23;
    }

    /* Estilos para los paneles de pedidos registrados */
    .pedido-panel {
      background-color: #fff3e0;
      border: 1px solid #8B5E3C;
      border-radius: 8px;
      padding: 1rem 1.5rem;
      margin-bottom: 1rem;
      box-shadow: 2px 2px 5px rgba(139, 94, 60, 0.3);
      color: #4e342e;
    }

    .pedido-panel h5 {
      margin-bottom: 0.5rem;
      font-weight: 700;
      color: #6f4e37;
    }

    .pedido-panel p {
      margin: 0.2rem 0;
    }
  </style>
</head>
<body>
  <div class="d-flex">
    <div class="sidebar">
      <div class="logo-container">
        <!-- Imagen de taza de café -->
        <img src="https://cdn-icons-png.flaticon.com/512/924/924514.png" alt="Taza de café" />
      </div>
      <h2>TRANQUILATTE CAFETERIA'S</h2>
      <ul class="nav flex-column px-3 text-start">
        <li class="nav-item"><a class="nav-link active" href="#inicio">🏠 Inicio</a></li>
        <li class="nav-item"><a class="nav-link" href="#pedidos">📦 Pedidos</a></li>
        <li class="nav-item"><a class="nav-link" href="#pedidos-linea">📝 Pedidos Registrados en Línea</a></li>
        <li class="nav-item"><a class="nav-link" href="#quejas">⚠️ Quejas</a></li>
        <li class="nav-item"><a class="nav-link" href="#sugerencias">💡 Sugerencias</a></li>
      </ul>
    </div>

    <div class="content">
      <div id="inicio">
        <h1>Bienvenido a Tranquilatte Cafeteria's</h1>
        <p>Administra los pedidos, quejas y sugerencias de nuestros clientes con facilidad.
           ¡Gracias por mantener Tranquilatte Cafeteria's funcionando!</p>
             <div style="margin-top: 20px;">
    <h5>Música para ambientar:</h5>
    <div style="background-color:rgba(139, 89, 52, 0.4); padding: 10px; border-radius: 15px; box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);">
 <iframe style="border-radius:12px" src="https://open.spotify.com/embed/playlist/5owdNDFJMVpNr4R9jpCsbK?utm_source=generator"
   width="100%" height="352" frameBorder="0" allowfullscreen="" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>
</div>
  </div>
      </div>
      <div id="pedidos" class="mt-5" style="display:none;">
        <h1>Gestión de Pedidos</h1>
        <form id="pedidoForm">
          <div class="mb-3">
            <label class="form-label">Cliente</label>
            <input type="text" class="form-control" id="pedidoCliente" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Producto</label>
            <input list="productosLista" class="form-control" id="pedidoProducto" required />
            <datalist id="productosLista">
              <option value="Espresso - $28.00">
              <option value="Americano - $25.00">
              <option value="Latte - $32.00">
              <option value="Cappuccino - $30.00">
              <option value="Macchiato - $29.00">
              <option value="Mocha - $35.00">
              <option value="Café helado - $33.00">
              <option value="Café descafeinado - $27.00">
              <option value="Té chai - $22.00">
              <option value="Té helado - $24.00">
              <option value="Matcha latte - $34.00">
              <option value="Chai latte - $33.00">
              <option value="Chocolate caliente - $28.00">
              <option value="Jugos naturales o prensados - $26.00">
              <option value="Smoothies - $29.00">
              <option value="Agua mineral o saborizada - $15.00">
              <option value="Gaseosas o refrescos - $18.00">
              <option value="Croissants - $22.00">
              <option value="Muffin de chocolate - $20.00">
              <option value="Brownies - $25.00">
              <option value="Galletas caseras - $18.00">
              <option value="Tarta - $27.00">
              <option value="Donas - $19.00">
              <option value="Yogur con granola y frutas - $28.00">
              <option value="Bowl de frutas - $27.00">
              <option value="Sandwiches (vegetariano, jamón y queso, pollo, etc.) - $35.00">
              <option value="Wraps - $33.00">
              <option value="Ensaladas - $30.00">
            </datalist>
          </div>

          <div class="mb-3">
            <label class="form-label">Cantidad</label>
            <input type="number" class="form-control" id="pedidoCantidad" required min="1" />
          </div>
          <button type="submit" class="btn btn-primary">Registrar Pedido</button>
        </form>
        <hr />
        <h3>Pedidos del Carrito de Compras</h3>
        <ul id="listaPedidos" class="list-group mt-3"></ul>
      </div>

      <div id="quejas" class="mt-5" style="display:none;">
        <h1>Quejas de Clientes</h1>
        <form id="formQueja">
          <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" class="form-control" id="quejaNombre" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Queja</label>
            <textarea class="form-control" id="quejaTexto" rows="3" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Enviar Queja</button>
        </form>
        <div id="listaQuejas" class="mt-4"></div>
      </div>

      <div id="sugerencias" class="mt-5" style="display:none;">
        <h1>Sugerencias</h1>
        <form id="formSugerencia">
          <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" class="form-control" id="sugerenciaNombre" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Sugerencia</label>
            <textarea class="form-control" id="sugerenciaTexto" rows="3" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Enviar Sugerencia</button>
        </form>
        <div id="listaSugerencias" class="mt-4"></div>
      </div>

      <div id="pedidos-registrados" class="mt-5" style="display:none;">
        <h1>Pedidos Registrados</h1>
        <div id="panelPedidosRegistrados" class="mt-3"></div>
      </div>

      <!-- SACAMOS pedidos-linea FUERA DE pedidos-registrados -->
      <div id="pedidos-linea" class="mt-5" style="display:none;">
        <h1>Pedidos Registrados en Línea</h1>
        <p>Puedes ver los pedidos en línea haciendo clic en el siguiente enlace:</p>
        <a href="leer_pedidos.php" target="_blank" class="btn btn-primary">Ver Pedidos en Línea</a>
      </div>
    </div>
  </div>

  <script>
    // Cambio de pestañas
    const links = document.querySelectorAll('.sidebar a.nav-link');
    const sections = {
      inicio: document.getElementById('inicio'),
      pedidos: document.getElementById('pedidos'),
      quejas: document.getElementById('quejas'),
      sugerencias: document.getElementById('sugerencias'),
      "pedidos-registrados": document.getElementById('pedidos-registrados'),
      "pedidos-linea": document.getElementById('pedidos-linea'),
    };

    function mostrarSeccion(id) {
      for (const key in sections) {
        if (sections[key]) {
          sections[key].style.display = 'none';
        }
      }
      if (sections[id]) {
        sections[id].style.display = 'block';
      }
      // Actualizar clase active en menú
      links.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === '#' + id) {
          link.classList.add('active');
        }
      });
    }

    links.forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        const targetId = link.getAttribute('href').substring(1);
        mostrarSeccion(targetId);
      });
    });

    // Mostrar la sección de inicio al cargar
    mostrarSeccion('inicio');

    // Manejo de formulario para pedidos (carrito)
    const pedidoForm = document.getElementById('pedidoForm');
    const listaPedidos = document.getElementById('listaPedidos');
    const pedidosCarrito = [];
    function renderPedidos() {
  listaPedidos.innerHTML = '';
  pedidosCarrito.forEach((pedido, index) => {
    const item = document.createElement('li');
    item.classList.add('list-group-item', 'd-flex', 'justify-content-between', 'align-items-center');
    item.innerHTML = `
      ${pedido.cliente} - ${pedido.producto} x${pedido.cantidad}
      <div>
        <button class="btn btn-sm btn-warning me-1" onclick="editarPedido(${index})">Editar</button>
        <button class="btn btn-sm btn-danger" onclick="eliminarPedido(${index})">Eliminar</button>
      </div>
    `;
    listaPedidos.appendChild(item);
  });
}

function editarPedido(index) {
  const pedido = pedidosCarrito[index];
  document.getElementById('pedidoCliente').value = pedido.cliente;
  document.getElementById('pedidoProducto').value = pedido.producto;
  document.getElementById('pedidoCantidad').value = pedido.cantidad;
  pedidosCarrito.splice(index, 1);
  renderPedidos();
}

function eliminarPedido(index) {
  pedidosCarrito.splice(index, 1);
  renderPedidos();
}

pedidoForm.addEventListener('submit', e => {
  e.preventDefault();
  const cliente = document.getElementById('pedidoCliente').value.trim();
  const producto = document.getElementById('pedidoProducto').value.trim();
  const cantidad = parseInt(document.getElementById('pedidoCantidad').value, 10);

  if (!cliente || !producto || cantidad <= 0) {
    alert('Por favor completa todos los campos correctamente.');
    return;
  }

  // Enviar a backend con fetch
  fetch('guardar_pedidoAdmin.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: `cliente=${encodeURIComponent(cliente)}&producto=${encodeURIComponent(producto)}&cantidad=${cantidad}`
  })
  .then(res => res.text())
  .then(respuesta => {
    if (respuesta === 'OK') {
      pedidosCarrito.push({ cliente, producto, cantidad });
      renderPedidos();
      pedidoForm.reset();
    } else {
      alert("Error al guardar: " + respuesta);
    }
  })
  .catch(err => {
    console.error('Error al enviar pedido:', err);
    alert("Ocurrió un error al conectar con el servidor.");
  });
});


    // Manejo de quejas
    const formQueja = document.getElementById('formQueja');
    const listaQuejas = document.getElementById('listaQuejas');
    const quejasArray = [];

    formQueja.addEventListener('submit', e => {
      e.preventDefault();
      const nombre = document.getElementById('quejaNombre').value.trim();
      const texto = document.getElementById('quejaTexto').value.trim();

      if (!nombre || !texto) {
        alert('Por favor completa todos los campos.');
        return;
      }

      quejasArray.push({ nombre, texto });
      renderQuejas();
      formQueja.reset();
    });

    function mostrarQuejas() {
      listaQuejas.innerHTML = '';
      quejasArray.forEach(q => {
        const div = document.createElement('div');
        div.classList.add('suggestion-card');
        div.innerHTML = `<strong>${q.nombre}:</strong> <p>${q.texto}</p>`;
        listaQuejas.appendChild(div);
      });
    }
    function renderQuejas() {
  listaQuejas.innerHTML = '';
  quejasArray.forEach((q, index) => {
    const div = document.createElement('div');
    div.classList.add('suggestion-card');
    div.innerHTML = `
      <strong>${q.nombre}:</strong> <p>${q.texto}</p>
      <button class="btn btn-sm btn-warning me-1" onclick="editarQueja(${index})">Editar</button>
      <button class="btn btn-sm btn-danger" onclick="eliminarQueja(${index})">Eliminar</button>
    `;
    listaQuejas.appendChild(div);
  });
}

function editarQueja(index) {
  const queja = quejasArray[index];
  document.getElementById('quejaNombre').value = queja.nombre;
  document.getElementById('quejaTexto').value = queja.texto;
  quejasArray.splice(index, 1);
  renderQuejas();
}

function eliminarQueja(index) {
  quejasArray.splice(index, 1);
  renderQuejas();
}


    // Manejo de sugerencias
    const formSugerencia = document.getElementById('formSugerencia');
    const listaSugerencias = document.getElementById('listaSugerencias');
    const sugerenciasArray = [];

    formSugerencia.addEventListener('submit', e => {
      e.preventDefault();
      const nombre = document.getElementById('sugerenciaNombre').value.trim();
      const texto = document.getElementById('sugerenciaTexto').value.trim();

      if (!nombre || !texto) {
        alert('Por favor completa todos los campos.');
        return;
      }

      sugerenciasArray.push({ nombre, texto });
      renderSugerencias();
      formSugerencia.reset();
    });

    function mostrarSugerencias() {
      listaSugerencias.innerHTML = '';
      sugerenciasArray.forEach(s => {
        const div = document.createElement('div');
        div.classList.add('suggestion-card');
        div.innerHTML = `<strong>${s.nombre}:</strong> <p>${s.texto}</p>`;
        listaSugerencias.appendChild(div);
      });
    }
    function renderSugerencias() {
  listaSugerencias.innerHTML = '';
  sugerenciasArray.forEach((s, index) => {
    const div = document.createElement('div');
    div.classList.add('suggestion-card');
    div.innerHTML = `
      <strong>${s.nombre}:</strong> <p>${s.texto}</p>
      <button class="btn btn-sm btn-warning me-1" onclick="editarSugerencia(${index})">Editar</button>
      <button class="btn btn-sm btn-danger" onclick="eliminarSugerencia(${index})">Eliminar</button>
    `;
    listaSugerencias.appendChild(div);
  });
}

function editarSugerencia(index) {
  const sugerencia = sugerenciasArray[index];
  document.getElementById('sugerenciaNombre').value = sugerencia.nombre;
  document.getElementById('sugerenciaTexto').value = sugerencia.texto;
  sugerenciasArray.splice(index, 1);
  renderSugerencias();
}

function eliminarSugerencia(index) {
  sugerenciasArray.splice(index, 1);
  renderSugerencias();
}


    // Aquí podrías agregar código para cargar y mostrar pedidos registrados, si tienes backend o localStorage.
  </script>
</body>
</html>

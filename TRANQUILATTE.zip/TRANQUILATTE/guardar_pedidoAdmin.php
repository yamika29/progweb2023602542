<?php
$conexion = new mysqli("localhost", "root", "", "cafes");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$cliente = $_POST['cliente'] ?? '';
$producto = $_POST['producto'] ?? '';
$cantidad = intval($_POST['cantidad'] ?? 0);

if ($cliente && $producto && $cantidad > 0) {
    $stmt = $conexion->prepare("INSERT INTO pedidos (nombre_cliente, producto, cantidad) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $cliente, $producto, $cantidad);
    $stmt->execute();
    echo "OK";
    $stmt->close();
} else {
    echo "Datos inválidos";
}

$conexion->close();
?>

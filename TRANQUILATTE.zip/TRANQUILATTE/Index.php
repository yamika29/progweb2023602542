<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Bienvenido a Tranquilatte</title>
    <link rel="stylesheet" href="css/estilos.css" />
    <style>
        /* Fondo con degradado suave café */
        body {
            margin: 0;
            height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #d7c4a3, #8b5e3c);
            display: flex;
            justify-content: center;
            align-items: center;
            color: #422d16;
            text-align: center;
            padding: 20px;
        }

        .bienvenida {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 25px;
            padding: 40px 50px;
            max-width: 600px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }

        .bienvenida h1 {
            font-size: 48px;
            margin-bottom: 15px;
            font-weight: 700;
            letter-spacing: 2px;
        }

        .bienvenida p {
            font-size: 20px;
            line-height: 1.5;
            margin-bottom: 35px;
            color: #5a4220;
        }

        .btn {
            display: inline-block;
            margin: 0 15px;
            padding: 15px 35px;
            font-size: 18px;
            font-weight: 600;
            color: #fff;
            background-color: #6f4e37;
            border-radius: 30px;
            text-decoration: none;
            box-shadow: 0 6px 12px rgba(0,0,0,0.3);
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #8b6f52;
        }
    </style>
</head>
<body>

    <div class="bienvenida">
        <h1>Tranquilatte ☕️</h1>
        <p>Bienvenido a tu espacio favorito para disfrutar del mejor café, bebidas especiales y deliciosos bocados en un ambiente relajado y acogedor.</p>
        <a href="productos.php" class="btn">Ver Menú</a>
    </div>

</body>
</html>

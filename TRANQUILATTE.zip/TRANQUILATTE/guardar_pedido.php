<?php
include 'conexion.php';
$data = json_decode(file_get_contents("php://input"));
$cliente = $conn->real_escape_string($data->cliente);
$producto = $conn->real_escape_string($data->producto);
$cantidad = (int)$data->cantidad;

$sql = "INSERT INTO pedidos (cliente, producto, cantidad) VALUES ('$cliente', '$producto', $cantidad)";
if ($conn->query($sql)) {
  echo json_encode(["status" => "success"]);
} else {
  echo json_encode(["status" => "error", "message" => $conn->error]);
}
$conn->close();
?>

<?php
session_start();

if (empty($_SESSION['carrito'])) {
    die("No hay productos en el carrito para confirmar la compra.");
}

// Calcular total
$productos = isset($_SESSION['carrito']) ? $_SESSION['carrito'] : [];
$total = 0;
foreach ($_SESSION['carrito'] as $item) {
    $subtotal = floatval($item['precio']) * intval($item['cantidad']);
    $total += $subtotal;
}
$_SESSION['ticket_total'] = $total;

$datos_pedido = null;
$error = "";


?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Confirmación de Compra</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fef9f5;
            margin: 0;
            padding: 0;
        }
        .contenedor {
            max-width: 800px;
            margin: 80px auto;
            background-color: white;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            position: relative;
        }
        .error {
            background-color: #fdd;
            border: 1px solid #d00;
            padding: 10px;
            margin-bottom: 15px;
            color: #900;
            border-radius: 5px;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
            color: #6b4226;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 1rem;
        }
        button {
            margin-top: 25px;
            background-color: #a0522d;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 1.1rem;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }
        button:hover {
            background-color: #8b4513;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .total {
            font-weight: bold;
            text-align: right;
            color: #d2691e;
            padding-top: 20px;
            font-size: 1.2em;
        }
        .btn-volver {
            display: block;
            width: 220px;
            margin: 40px auto 0;
            padding: 12px;
            text-align: center;
            background-color: #a0522d;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s;
        }
        .btn-volver:hover {
            background-color: #8b4513;
        }
    </style>
</head>
<body>
    <div class="contenedor">

        <?php if ($datos_pedido === null): ?>
            <h1>Datos para tu pedido</h1>

            <?php if ($error): ?>
                <div class="error"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST" action="finalizar.php">
                <label for="nombre_cliente">Nombre completo</label>
                <input type="text" id="nombre_cliente" name="nombre_cliente" required>

                <label for="direccion">Dirección de entrega</label>
                <input type="text" id="direccion" name="direccion" required>

                <label for="telefono">Número de teléfono</label>
                <input type="tel" id="telefono" name="telefono" 
                pattern="[0-9\s\-]{7,10}" maxlength="10"
                inputmode="numeric" required placeholder="Ejemplo: +521234567890">

                <label for="metodo_pago">Método de pago</label>
                <select id="metodo_pago" name="metodo_pago" required>
                    <option value="">-- Selecciona --</option>
                    <option value="Tarjeta de crédito">Tarjeta de crédito</option>
                    <option value="Tarjeta de débito">Tarjeta de débito</option>
                    <option value="PayPal">PayPal</option>
                    <option value="Efectivo">Efectivo</option>
                </select>
                <!-- Campos adicionales según el método de pago -->
<div id="paypal_info" style="display:none;">
    <label for="paypal_correo">Correo de PayPal</label>
    <input type="email" id="paypal_correo" name="paypal_correo" pattern=".+@paypal\.com" placeholder="usuario@paypal.com">
</div>

<div id="datos_tarjeta" style="display: none;">
    <label for="numero_tarjeta">Número de tarjeta</label>
<input type="text" id="numero_tarjeta" name="numero_tarjeta"
       pattern="\d{16}" maxlength="16"
       inputmode="numeric" placeholder="1234567812345678">

   <label for="cvv">CVV</label>
<input type="text" id="cvv" name="cvv"
       pattern="\d{3}" maxlength="3"
       inputmode="numeric" placeholder="123">

    <label for="vencimiento">Fecha de vencimiento (MM/AA)</label>
    <input type="text" id="vencimiento" name="vencimiento" maxlength="5" placeholder="MM/AA">
</div>

<div id="datos_paypal" style="display: none;">
    <label for="correo_paypal">Correo de PayPal</label>
    <input type="email" id="correo_paypal" name="correo_paypal" pattern=".+@paypal\.com" placeholder="ejemplo@paypal.com">
</div>



                <button type="submit" name="confirmar_pedido">Confirmar pedido</button>
            </form>

        <?php else: ?>
            <h1>¡Gracias por tu compra, <?= htmlspecialchars($datos_pedido['nombre_cliente']) ?>!</h1>
            <p><strong>Dirección de entrega:</strong> <?= htmlspecialchars($datos_pedido['direccion']) ?></p>
            <p><strong>Teléfono:</strong> <?= htmlspecialchars($datos_pedido['telefono']) ?></p>
            <p><strong>Método de pago:</strong> <?= htmlspecialchars($datos_pedido['metodo_pago']) ?></p>

            <?php if (count($productos) > 0): ?>
                <table>
                    <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>Subtotal</th>
                    </tr>
                    <?php 
                    foreach ($productos as $nombre => $producto): 
                        $subtotal = $producto['precio'] * $producto['cantidad'];
                        $total += $subtotal;
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($nombre) ?></td>
                            <td>$<?= number_format($producto['precio'], 2) ?></td>
                            <td><?= $producto['cantidad'] ?></td>
                            <td>$<?= number_format($subtotal, 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
                <div class="total">Total: $<?= number_format($total, 2) ?></div>
            <?php else: ?>
                <p>Tu carrito estaba vacío. No se realizó ninguna compra.</p>
            <?php endif; ?>

    Descargar ticket en PDF</a>
<a href="generar_ticket.php" style="display:block; margin-top:20px; text-align:center; background:#a0522d; color:#fff; padding:12px 0; border-radius:10px; text-decoration:none; font-weight:bold;">
    Descargar ticket en PDF</a>

            <a class="btn-volver" href="productos.php">Volver al menú principal</a>

            <?php
if ($datos_pedido && count($productos) > 0) {
    $pedido_completo = [
        'cliente' => $datos_pedido,
        'productos' => $productos,
        'total' => $total,
        'fecha' => date('Y-m-d H:i:s')
    ];

    $archivo = 'pedidos.json';
    $contenido_actual = [];

    if (file_exists($archivo)) {
        $json_actual = file_get_contents($archivo);
        $contenido_actual = json_decode($json_actual, true) ?? [];
    }

    $contenido_actual[] = $pedido_completo;

    file_put_contents($archivo, json_encode($contenido_actual, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}
?>


            <?php 
                $_SESSION['carrito'] = [];
                unset($_SESSION['datos_pedido']);
            ?>
        <?php endif; ?>

    </div>

    <!-- Script para guardar el carrito en localStorage -->
    <script>
        <?php if (!empty($productos)): ?>
            const pedidos = <?= json_encode($productos) ?>;
            localStorage.setItem('carrito', JSON.stringify(pedidos));
        <?php endif; ?>
    </script>
    <script>
    const metodoPago = document.getElementById('metodo_pago');
    const datosTarjeta = document.getElementById('datos_tarjeta');
    const datosPayPal = document.getElementById('datos_paypal');
    const vencimientoInput = document.getElementById('vencimiento');

    metodoPago.addEventListener('change', () => {
        datosTarjeta.style.display = 'none';
        datosPayPal.style.display = 'none';

        if (metodoPago.value === 'Tarjeta de crédito' || metodoPago.value === 'Tarjeta de débito') {
            datosTarjeta.style.display = 'block';
        } else if (metodoPago.value === 'PayPal') {
            datosPayPal.style.display = 'block';
        }
    });

    // Agrega la diagonal automáticamente en la fecha de vencimiento
    vencimientoInput?.addEventListener('input', function (e) {
        let val = e.target.value.replace(/\D/g, '');
        if (val.length >= 3) {
            val = val.substring(0, 2) + '/' + val.substring(2, 4);
        }
        e.target.value = val;
    });
</script>

<script>
// Función para bloquear letras en campos numéricos
function soloNumeros(evt) {
    const charCode = evt.which ? evt.which : evt.keyCode;
    if (charCode < 48 || charCode > 57) {
        evt.preventDefault();
    }
}

// Aplica la función a los campos deseados
document.getElementById('telefono').addEventListener('keypress', soloNumeros);
document.getElementById('numero_tarjeta').addEventListener('keypress', soloNumeros);
document.getElementById('cvv').addEventListener('keypress', soloNumeros);
</script>

</body>
</html>

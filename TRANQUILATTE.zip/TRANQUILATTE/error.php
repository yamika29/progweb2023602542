<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Tranquilatte - Error de acceso</title>
    <style>
        body {
             background-image: url('img/fondo-cafe.jpg');
            background-color: #fff8f0;
            color:rgb(54, 39, 29); /* tono café */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            text-align: center;
            padding-top: 100px;
        }
        h1 {
            font-size: 2.5em;
            margin-bottom: 20px;
        }

      .logo {
    font-size: 4em;
    background-image: url('img/taza.png');
    background-size: cover;
    background-position: center;
    width: 200px;
    height: 200px;
    margin: 0 auto 20px;
    line-height: 100px;
    border-radius: 50%;
}

        button {
            background-color:rgb(91, 70, 58);
            color: white;
            border: none;
            padding: 15px 15px;
            font-size: 1em;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background-color: #8a5e3b;
        }
    </style>
</head>

<body>
    <div class="logo"></div>
    <h1>CREDENCIALES INVÁLIDAS</h1>
    <form action="login.php" method="get">
        <button type="submit">REGRESAR</button>
    </form>
</body>
</html>

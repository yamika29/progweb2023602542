<?php
$servidor = "localhost";
$usuario = "root";
$contrasena = ""; // XAMPP no tiene contraseña por defecto
$bd = "cafes";

// Conexión
$conn = new mysqli($servidor, $usuario, $contrasena, $bd);

// Verificación
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>

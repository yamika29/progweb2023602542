<?php
session_start();

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = array();
}

// Agregar producto
if (isset($_GET['agregar'])) {
    $producto = $_GET['agregar'];
    $precio = floatval($_GET['precio']);
    if (isset($_SESSION['carrito'][$producto])) {
        $_SESSION['carrito'][$producto]['cantidad']++;
    } else {
        $_SESSION['carrito'][$producto] = ['precio' => $precio, 'cantidad' => 1];
    }
    // Para evitar reenvío de datos si refrescan, redirigimos
    header("Location: carrito.php");
    exit;
}

// Sumar cantidad
if (isset($_GET['sumar'])) {
    $producto = $_GET['sumar'];
    if (isset($_SESSION['carrito'][$producto])) {
        $_SESSION['carrito'][$producto]['cantidad']++;
    }
    header("Location: carrito.php");
    exit;
}

// Restar cantidad
if (isset($_GET['restar'])) {
    $producto = $_GET['restar'];
    if (isset($_SESSION['carrito'][$producto])) {
        $_SESSION['carrito'][$producto]['cantidad']--;
        if ($_SESSION['carrito'][$producto]['cantidad'] < 1) {
            unset($_SESSION['carrito'][$producto]);
        }
    }
    header("Location: carrito.php");
    exit;
}

// Vaciar carrito
if (isset($_GET['vaciar'])) {
    unset($_SESSION['carrito']);
    header("Location: carrito.php");
    exit;
}

$total = 0;
foreach ($_SESSION['carrito'] as $item) {
    $total += $item['precio'] * $item['cantidad'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Carrito - Tranquilatte</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: #faf7f3;
            color: #4a3c31;
            margin: 0; padding: 20px;
        }
        header {
            background: #6f4e37;
            color: white;
            padding: 20px 40px;
            text-align: center;
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
            margin-bottom: 40px;
        }
        h1 {
            margin: 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            padding: 15px;
            border-bottom: 1px solid #d9cbbd;
            text-align: center;
        }
        th {
            background-color: #a07c58;
            color: white;
        }
        td {
            font-weight: 600;
            font-size: 1.05rem;
        }
        .total {
            font-size: 1.3rem;
            font-weight: 700;
            text-align: right;
            margin-bottom: 40px;
        }
        a.button {
            background-color: #6f4e37;
            color: white;
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            letter-spacing: 0.05em;
            margin-right: 15px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
        a.button:hover {
            background-color: #a07c58;
        }
        .botones {
            text-align: center;
        }
        .cantidad-control {
            display: flex;
            justify-content: center;
            gap: 10px;
            align-items: center;
        }
        .cantidad-control a {
            background: #6f4e37;
            color: white;
            padding: 4px 12px;
            border-radius: 8px;
            font-weight: 700;
            text-decoration: none;
            user-select: none;
            transition: background-color 0.3s ease;
        }
        .cantidad-control a:hover {
            background: #a07c58;
        }
        .cantidad-control span {
            font-weight: 600;
            font-size: 1.1rem;
        }
    </style>
</head>
<body>
    <header>
        <h1>Tu carrito en Tranquilatte</h1>
    </header>

    <?php if (empty($_SESSION['carrito'])): ?>
    <p style="text-align:center; font-size:1.2rem; font-weight:600;">Tu carrito está vacío.</p>
    <div style="text-align:center; margin-top: 20px;">
        <a href="productos.php" class="button">Volver al menú</a>
    </div>
<?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Precio Unitario</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($_SESSION['carrito'] as $nombre => $item): ?>
                <tr>
                    <td><?= htmlspecialchars($nombre) ?></td>
                    <td>$<?= number_format($item['precio'], 2) ?></td>
                    <td>
                        <div class="cantidad-control">
                            <a href="carrito.php?restar=<?= urlencode($nombre) ?>">&minus;</a>
                            <span><?= $item['cantidad'] ?></span>
                            <a href="carrito.php?sumar=<?= urlencode($nombre) ?>">&plus;</a>
                        </div>
                    </td>
                    <td>$<?= number_format($item['precio'] * $item['cantidad'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="total">Total a pagar: $<?= number_format($total, 2) ?></div>

        <div class="botones">
            <a href="productos.php" class="button">Seguir comprando</a>
            <a href="carrito.php?vaciar=1" class="button" style="background:#c75d5d;">Vaciar carrito</a>
            <a href="confirmacion.php" class="button" style="background:#5da563;">Confirmar compra</a>
        </div>
    <?php endif; ?>
</body>
</html>

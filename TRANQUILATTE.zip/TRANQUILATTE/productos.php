<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Menú - Cafetería Tranquilatte</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600&display=swap" rel="stylesheet" />
  <style>
    html {
      scroll-behavior: smooth;
    }
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background: #fdf9f5;
      color: #3f3223;
    }
    header {
      background: #6f4e37;
      color: #fff;
      padding: 30px;
      text-align: center;
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }
    header h1 {
      margin: 0;
      font-size: 2.8rem;
      font-weight: 600;
      letter-spacing: 2px;
    }
    nav {
      margin-top: 15px;
    }
    nav a {
      display: inline-block;
      margin: 10px;
      padding: 10px 25px;
      border: 2px solid #d6b18e;
      border-radius: 30px;
      text-decoration: none;
      color: #d6b18e;
      font-weight: 600;
      transition: all 0.3s ease;
    }
    nav a:hover {
      background-color: #d6b18e;
      color: #6f4e37;
    }
    .section-nav {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      margin: 30px auto;
      max-width: 1100px;
      gap: 10px;
    }
    .section-nav button {
      background: #fff;
      border: 2px solid #c7a589;
      color: #6f4e37;
      padding: 12px 20px;
      border-radius: 25px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    .section-nav button:hover {
      background: #c7a589;
      color: #fff;
    }
    main {
      max-width: 1100px;
      margin: 0 auto;
      padding: 40px 20px;
    }
    h2 {
      text-align: center;
      font-size: 2.4rem;
      font-weight: 600;
      color: #5c4936;
      margin-bottom: 40px;
    }
    h3.section-title {
      text-align: center;
      font-size: 1.8rem;
      margin: 60px 0 25px;
      color: #6f4e37;
      position: relative;
    }
    h3.section-title::after {
      content: '';
      width: 60px;
      height: 4px;
      background: #d6b18e;
      display: block;
      margin: 12px auto 0;
      border-radius: 2px;
    }
    .productos {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 30px;
    }
    .producto {
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: transform 0.3s ease;
    }
    .producto:hover {
      transform: translateY(-5px);
    }
    .producto img {
      width: 100%;
      height: 320px;
      object-fit: cover;
      border-top-left-radius: 20px;
      border-top-right-radius: 20px;
    }
    .producto h3 {
      font-size: 1.3rem;
      margin: 18px 20px 8px;
      color: #5c3d2e;
    }
    .producto p {
      margin: 0 20px 20px;
      font-weight: 600;
      color: #8a6e53;
    }
    .producto button {
      display: block;
      width: calc(100% - 40px);
      margin: 0 20px 20px;
      padding: 12px 0;
      border: none;
      border-radius: 35px;
      background-color: #6f4e37;
      color: #fff;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    .producto button:hover {
      background-color: #a07c58;
    }
    .seccion {
      display: none;
    }
    .seccion.active {
      display: block;
    }
  </style>
  <script>
    function mostrarSeccion(id) {
      const secciones = document.querySelectorAll(".seccion");
      secciones.forEach(sec => sec.classList.remove("active"));
      document.getElementById(id).classList.add("active");
    }
  </script>
</head>
<body>
  <header>
    <h1>Bienvenido a Tranquilatte</h1>
    <nav>
      <a href="carrito.php">Ver Carrito 🛒</a>
    </nav>
  </header>

  <main>
    <h2>Nuestro Menú</h2>

    <div class="section-nav">
      <button onclick="mostrarSeccion('cafes')">Cafés Clásicos</button>
      <button onclick="mostrarSeccion('tes')">Tés y Bebidas</button>
      <button onclick="mostrarSeccion('reposteria')">Repostería y Snacks</button>
      <button onclick="mostrarSeccion('comidas')">Comidas Ligeras</button>
    </div>

    <?php
    $secciones = [
        "Cafés Clásicos" => [
            ["Espresso", 28.00, "espress.jpg"],
            ["Americano", 25.00, "americano.jpg"],
            ["Latte", 32.00, "latte.jpg"],
            ["Cappuccino", 30.00, "capuccino.jpg"],
            ["Macchiato", 29.00, "machiato.jpg"],
            ["Mocha", 35.00, "mocha.jpg"],
            ["Café helado", 33.00, "chelado.jpg"],
            ["Café descafeinado", 27.00, "descafeinado.jpg"]
        ],
        "Tés y Bebidas" => [
            ["Té chai", 22.00, "techai.jpg"],
            ["Té helado", 24.00, "tehelado.jpg"],
            ["Matcha latte", 34.00, "matcha.jpg"],
            ["Chai latte", 33.00, "chai.jpg"],
            ["Chocolate caliente", 28.00, "choco.jpg"],
            ["Jugos naturales o prensados", 26.00, "jugo.jpg"],
            ["Smoothies", 29.00, "smo.jpg"],
            ["Agua mineral o saborizada", 15.00, "aguam.jpg"],
            ["Gaseosas o refrescos", 18.00, "gas.jpg"]
        ],
        "Repostería y Snacks" => [
            ["Croissants", 22.00, "cro.jpg"],
            ["Muffin de chocolate ", 20.00, "muffin.jpg"],
            ["Brownies", 25.00, "brownie.jpg"],
            ["Galletas caseras", 18.00, "galleta.jpg"],
            ["Tarta", 27.00, "tarta.jpg"],
            ["Donas", 19.00, "dona.jpg"],
            ["Yogur con granola y frutas", 28.00, "yogurgranola.jpg"],
            ["Bowl de frutas", 27.00, "bowlfrutas.jpg"]
        ],
        "Comidas Ligeras" => [
            ["Sandwiches (vegetariano, jamón y queso, pollo, etc.)", 35.00, "san.jpg"],
            ["Wraps", 33.00, "wraps.jpg"],
            ["Ensaladas", 30.00, "ensalada.jpg"]
        ]
    ];

    $ids = ["Cafés Clásicos" => "cafes", "Tés y Bebidas" => "tes", "Repostería y Snacks" => "reposteria", "Comidas Ligeras" => "comidas"];

    foreach ($secciones as $titulo => $productos) {
        $id = $ids[$titulo];
        echo "<div id='$id' class='seccion'>";
        echo "<h3 class='section-title'>$titulo</h3>";
        echo "<div class='productos'>";
        foreach ($productos as $producto) {
            $nombre = $producto[0];
            $precio = $producto[1];
            $imagen = "img/" . $producto[2]; // Cambié la ruta a la carpeta img
            echo "
            <div class='producto'>
                <img src='$imagen' alt='$nombre' loading='lazy'>
                <h3>$nombre</h3>
                <p>$$precio</p>
                <a href='carrito.php?agregar=" . urlencode($nombre) . "&precio=$precio'>
                    <button>Agregar al carrito</button>
                </a>
            </div>
            ";
        }
        echo "</div></div>";
    }
    ?>

    <script>
      // Mostrar por defecto la primera sección (cafés)
      document.addEventListener("DOMContentLoaded", () => {
        mostrarSeccion("cafes");
      });
    </script>

  </main>
</body>
</html>
